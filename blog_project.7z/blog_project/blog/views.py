from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseRedirect
from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse, reverse_lazy
from .models import Post, Category, Like
from .forms import CustomUserCreationForm
from django.http import HttpResponse


def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid:
            form.save()
            return HttpResponseRedirect(reverse_lazy(reverse("blog:index")))
    else:
        form = CustomUserCreationForm()
        data = {"form": form}
        return render(request, "registration/register.html", data)


class PostListView(ListView):
    model = Post


class PostCreateView(CreateView):
    model = Post
    fields = "__all__"
    success_url = reverse_lazy("blog:index")


class PostDeleteView(DeleteView):
    model = Post
    success_url = reverse_lazy('blog:index')


class PostUpdateView(UpdateView):
    model = Post
    fields = "__all__"
    success_url = reverse_lazy('blog:index')


class PostDetailView(DetailView):
    model = Post


class CategoryListView(ListView):
    model = Category
    template_name = "category_lsit"


class CategoryDetailView(DetailView):
    model = Category


def add_like(request, pk):
    post = get_object_or_404(Post, pk=pk)
    like = Like(user=request.user, post=post)
    like.save()
    return redirect('blog:post_detail', pk=pk)

def remove_like(request, pk):
    post = get_object_or_404(Post, pk=pk)
    like = Like.objects.get(user=request.user, post=post)
    like.delete()
    return redirect('blog:post_detail', pk=pk)